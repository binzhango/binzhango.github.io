# LangChain agents with Muse Glimmer and shared memory

A runnable Python sample inside your existing Hindsight fork. Two role-based LangChain agents (`planner`, `coder`) use LM Studio's **muse-glimmer-30b**. Hindsight supplies persistent context shared by agents working for the same user and project.

```mermaid
flowchart LR
 P[Planner] --> W[MemoryAgent wrapper]
 C[Coder] --> W
 W --> R[Recall user/project facts]
 R --> H[Hindsight :8889]
 W --> L[LM Studio :1234 / Muse Glimmer]
 E[Explicit remember command] --> H
 H --> L
 H --> D[Dedicated PostgreSQL volume]
```

This is a small message-based agent example. Your existing agents can keep their business tools and orchestration; add the memory boundary around their invocation. Retrieval runs automatically before a question. Writes are explicit, so an assistant's speculation is not silently learned as a user fact.

See [how the agent works](HOW_IT_WORKS.md) for the request flow, memory-write policy, and interpretation of the benchmark.

## Quick start on your Mac

Run these from this directory:

```sh
rtk proxy uv sync --frozen
rtk proxy cp .env.example .env
rtk proxy lms server start --port 1234 --bind 127.0.0.1
rtk proxy lms load muse-glimmer-30b --identifier muse-glimmer-30b --context-length 16384 --ttl 3600 --yes
rtk proxy docker compose up -d
rtk proxy uv run memory-agents doctor
```

The installed local model was discovered as `muse-glimmer-30b` (Muse Glimmer 30B UD, Q6_K_XL). The sample uses that exact API identifier. Model load uses a one-hour idle TTL; re-load it if needed. `doctor` checks model discovery and Hindsight health; it does not prove that extraction works.

- Agent process → LM Studio: `http://localhost:1234/v1`.
- Agent process → sample Hindsight API: `http://localhost:8889`.
- Hindsight container → LM Studio: `http://host.docker.internal:1234/v1`.
- Sample control plane: <http://localhost:9998>.
- Your original Hindsight instance remains at port 8888. This sample has its own volume and Compose project.

Compose pins the already-installed image digest. Embeddings/reranking use the image's local defaults; extraction uses LM Studio. Observations and automatic consolidation are disabled in this introductory sample so its first experiment focuses on raw facts and retrieval. Enable them later and evaluate the additional model work. Model artifacts may need downloading on a fresh machine; fully offline startup is not assumed.

If LM Studio authentication is enabled, set `LM_STUDIO_API_KEY` in `.env`; Compose forwards it to Hindsight. The sample supports `HINDSIGHT_API_KEY` when connecting to an authenticated memory service. Keep `.env` local.

## Try cross-agent memory

Every command is a separate process, so remembered context comes from Hindsight rather than an in-memory conversation.

```sh
rtk proxy uv run memory-agents remember 'For this project Alice requires Python, SQLite, and no paid external APIs.' --user sample-alice --project lmstudio-demo --agent planner --document-id project-constraints
rtk proxy uv run memory-agents recall 'What are the project constraints?' --user sample-alice --project lmstudio-demo
rtk proxy uv run memory-agents ask 'Suggest a minimal implementation stack for my project.' --user sample-alice --project lmstudio-demo --agent coder
rtk proxy uv run memory-agents ask 'Give a three-step implementation plan using my project constraints.' --user sample-alice --project lmstudio-demo --agent planner
```

Answers include the bank ID and retrieved facts alongside generated text. Inspect the evidence rather than accepting a fluent answer as proof of memory.

Compare with `ask ... --no-memory`, which makes the same model request without recall. For a second user, change `--user`; for a separate project, change `--project`. The two identities are encoded unambiguously and hashed into the bank name. Role/agent is deliberately excluded from bank identity so planner and coder share context. The caller must derive identity from its own authenticated user; these CLI flags are demo inputs, not authentication.

To update a source, repeat `remember` with the same `--document-id`. Use different document IDs for independent facts. The default is a new UUID. `ask` does not retain its prompt or answer automatically.

## Add this to several current agents

1. Create one `MemoryService` per application lifecycle and close it on shutdown.
2. Resolve `Scope(user_id, project_id)` from application identity on each request.
3. Give each agent its own instructions, tools, and conversation/checkpoint state.
4. Recall using the **current question**, then pass the returned facts into the agent request.
5. Retain selected verified preferences, decisions, or outcomes, with source-document IDs. Avoid replaying the whole transcript after every turn.

For message-based LangChain runnables:

```python
from memory_agents import MemoryAgent, MemoryService, Scope, Settings

settings = Settings.from_env()
memory = MemoryService(settings)
try:
    coder = MemoryAgent(settings.chat_model(), memory, "You are a coding assistant.")
    planner = MemoryAgent(settings.chat_model(), memory, "You are a project planner.")
    scope = Scope(user="authenticated-user-id", project="project-id")
    answer = await coder.ask(scope, "Which database should I use?")
    print(answer.text, answer.memories)
    # Same scope gives planner access to the same stored facts.
    plan = await planner.ask(scope, "Plan the implementation.")
finally:
    await memory.close()
```

For an existing LangGraph/LangChain agent that accepts a messages dictionary, adapt its input/output shape:

```python
from langchain_core.runnables import RunnableLambda

# Construct this closure per request with the correct existing agent/session.
async def invoke_existing(messages):
    result = await existing_agent.ainvoke(
        {"messages": messages},
        config={"configurable": {"thread_id": session_id}},
    )
    return result["messages"][-1]

augmented = MemoryAgent(RunnableLambda(invoke_existing), memory, "Follow this agent's task instructions.")
answer = await augmented.ask(scope, question)
```

That excerpt is an integration recipe: `existing_agent`, `session_id`, `memory`, `scope`, and `question` come from your app. It does not change your existing business tools. Ensure checkpoint IDs are scoped per user/session. If an existing agent already adds memory, integrate at one boundary to avoid duplicate recall and repeated context. Agents with custom state/output need a corresponding adapter.

For agent-selected memory tools, the repository also has `hindsight-langgraph.create_hindsight_tools`; see the [learning chapter](../../docs/learning-guide/04-langchain-langgraph.md). The current sample uses deterministic hooks so tool-calling quality is not a prerequisite.

## Files and tests

| File | Purpose |
|---|---|
| `src/memory_agents/app.py` | Settings, user/project scope, reusable memory service, agent wrapper |
| `src/memory_agents/cli.py` | Doctor, explicit remember, recall, and agent commands |
| `.env.example` | Local connection settings |
| `compose.yaml` | Isolated memory service with persistent volume and LM Studio extraction |
| `tests/test_app.py` | Routing, isolation of scope IDs, baseline, failure visibility, explicit-write policy |
| `uv.lock` | Resolved Python dependency versions |

```sh
rtk proxy uv run pytest -q
rtk proxy uv run ruff check src tests
rtk proxy uv run ruff format --check src tests
```

Memory failures stop this sample's request rather than silently giving a memory-free answer. `--no-memory` is the explicit baseline. Empty recall remains a valid result; a first-time user's missing bank is treated as empty memory until the first explicit retain creates it. The wrapper labels memory as untrusted evidence; this is prompt hygiene, not a security guarantee. The sample is a local demonstration, not a multi-tenant authorization system.

Stop the sample with `rtk proxy docker compose down`; the named volume persists. `down -v` removes its data, so use it only when intentionally resetting the demo. Stop LM Studio separately with `rtk proxy lms server stop` if desired.

## Run the local benchmark

The benchmark compares three modes: empty memory, Hindsight recall, and the original facts supplied directly in the prompt. It uses six questions, two repeats, the same Muse Glimmer model, fresh messages for every request, temperature 0, and deterministic JSON answer scoring. It records retrieval latency, model latency, total latency, tokens, evidence, and raw answers. Memory ingestion is timed separately.

From this directory, choose a new output directory for each run:

```sh
rtk proxy uv run python -m memory_agents.benchmark --output benchmarks/my-run --repeats 2
```

Each run creates a fresh synthetic memory bank and leaves it available for inspection. See the [measured local results](benchmarks/2026-11-05-local/REPORT.md) and [benchmark code](src/memory_agents/benchmark.py). This small experiment evaluates remembering project facts; it does not measure general coding ability or large-scale retrieval.

## Primary references

- [LM Studio OpenAI-compatible endpoints](https://lmstudio.ai/docs/developer/openai-compat)
- [LM Studio structured output](https://lmstudio.ai/docs/developer/openai-compat/structured-output)
- [LangChain ChatOpenAI reference](https://reference.langchain.com/python/langchain-openai/chat_models/base)
- [Observed verification](VERIFICATION.md)
